(function(){ace.require(["ace/snippets/json"],function(e){if(typeof module=="object"&&typeof exports=="object"&&module){module.exports=e}})})();
//# sourceMappingURL=json.js.map