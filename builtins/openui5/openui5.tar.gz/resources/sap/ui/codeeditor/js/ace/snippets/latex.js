(function(){ace.require(["ace/snippets/latex"],function(e){if(typeof module=="object"&&typeof exports=="object"&&module){module.exports=e}})})();
//# sourceMappingURL=latex.js.map